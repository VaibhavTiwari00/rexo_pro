<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class tbl_aggregator_ndr_data extends Model
{
    //
    protected $table = 'tbl_aggregator_ndr_data';

    protected $fillable = [];
}
